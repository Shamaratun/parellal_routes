export default function PatientProfilePage() {
    return (
        <div>
       
        </div>
    );
}