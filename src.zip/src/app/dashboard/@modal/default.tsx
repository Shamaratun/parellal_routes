export default function DefaultModal() {
  return null; 
}