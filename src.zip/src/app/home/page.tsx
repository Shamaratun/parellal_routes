export default function HomePage() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">🏠 Home</h1>
      <p>This is your home page.</p>
    </div>
  );
}
