import PatientProfilePage from "./dashboard/patient-profile/page";

export default function HomePage() {
  return (
    <>
        </>
  );
}